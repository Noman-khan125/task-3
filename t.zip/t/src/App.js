import React from 'react'
import Contact from './component/Contact'
import ReactContact from './component/reactContact'
const App = () => {
  return (
    <>
    <Contact/>
    <ReactContact/>
    </>
  )
}

export default App